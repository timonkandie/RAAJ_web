/**
 * Toast Notification Engine
 * Displays floating glassmorphism notifications with automatic dismiss timers.
 */
const Toast = {
  containerEl: null,

  initContainer() {
    if (!this.containerEl) {
      this.containerEl = document.createElement('div');
      this.containerEl.id = 'toast-container';
      this.containerEl.style.cssText = `
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 1100;
        display: flex;
        flex-direction: column;
        gap: 12px;
        pointer-events: none;
      `;
      document.body.appendChild(this.containerEl);
    }
  },

  /**
   * Show Toast Notification
   * @param {string} message - Notification text
   * @param {string} [type='info'] - Status type ('success', 'error', 'info', 'warning')
   * @param {number} [duration=4000] - Duration in milliseconds
   */
  show(message = '', type = 'info', duration = 4000) {
    this.initContainer();

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.style.pointerEvents = 'auto';

    const icons = {
      success: '✓',
      error: '✕',
      warning: '⚠️',
      info: 'ℹ️'
    };

    toast.innerHTML = `
      <span class="toast-icon">${icons[type] || 'ℹ️'}</span>
      <span class="toast-message">${message}</span>
      <button class="toast-close" aria-label="Dismiss">✕</button>
    `;

    this.containerEl.appendChild(toast);

    // Close button click
    const closeBtn = toast.querySelector('.toast-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.dismiss(toast));
    }

    // Auto dismiss
    setTimeout(() => {
      this.dismiss(toast);
    }, duration);
  },

  dismiss(toast) {
    if (!toast || toast.classList.contains('dismissing')) return;
    toast.classList.add('dismissing');
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(20px)';
    toast.style.transition = 'all 0.3s ease';

    setTimeout(() => {
      toast.remove();
    }, 300);
  }
};

window.Toast = Toast;
