/**
 * Dynamic Component Loader & Component Library Generators
 */

/**
 * Section Title Component Generator
 */
function createSectionTitle({ badge, title = '', highlightText = '', subtitle = '', align = 'center' }) {
  const alignClass = align === 'left' ? 'text-left' : align === 'right' ? 'text-right' : 'text-center';
  
  let formattedTitle = title;
  if (highlightText && title.includes(highlightText)) {
    formattedTitle = title.replace(
      highlightText,
      `<span class="text-gradient">${highlightText}</span>`
    );
  }

  const badgeHTML = badge
    ? `<div class="section-badge"><span class="section-badge-dot"></span>${badge}</div>`
    : '';

  const subtitleHTML = subtitle
    ? `<p class="section-subtitle">${subtitle}</p>`
    : '';

  return `
    <div class="section-header ${alignClass}">
      ${badgeHTML}
      <h2 class="section-title">${formattedTitle}</h2>
      ${subtitleHTML}
    </div>
  `.trim();
}

function initSectionHeaderComponents() {
  const containers = document.querySelectorAll('[data-component="section-title"]');
  containers.forEach(container => {
    const badge = container.dataset.badge;
    const title = container.dataset.title;
    const highlightText = container.dataset.highlight;
    const subtitle = container.dataset.subtitle;
    const align = container.dataset.align || 'center';

    if (title) {
      container.innerHTML = createSectionTitle({ badge, title, highlightText, subtitle, align });
    }
  });
}

/**
 * Service Card Component Generator
 */
function createServiceCard({ icon = '🎨', title = '', description = '', software = [], linkUrl = 'services.html', ctaText = 'Learn More' }) {
  const tagsHTML = software.length > 0
    ? `<div class="tag-group">${software.map(tool => `<span class="tag">${tool}</span>`).join('')}</div>`
    : '';

  return `
    <div class="card service-card">
      <div class="service-card-icon">${icon}</div>
      <h3 class="service-card-title">${title}</h3>
      <p class="service-card-desc">${description}</p>
      ${tagsHTML}
      <div class="service-card-footer">
        <a href="${linkUrl}" class="service-card-link">${ctaText} →</a>
      </div>
    </div>
  `.trim();
}

function createServiceGrid(servicesList = []) {
  if (!Array.isArray(servicesList) || servicesList.length === 0) return '';
  const cardsHTML = servicesList.map(service => createServiceCard(service)).join('');
  return `<div class="grid grid-3-col">${cardsHTML}</div>`;
}

function initServiceCardComponents() {
  const cardContainers = document.querySelectorAll('[data-component="service-card"]');
  cardContainers.forEach(container => {
    const icon = container.dataset.icon || '🎨';
    const title = container.dataset.title || '';
    const description = container.dataset.description || '';
    const software = container.dataset.software ? container.dataset.software.split(',').map(s => s.trim()) : [];
    const linkUrl = container.dataset.url || 'services.html';
    const ctaText = container.dataset.cta || 'Learn More';

    if (title) {
      container.innerHTML = createServiceCard({ icon, title, description, software, linkUrl, ctaText });
    }
  });
}

/**
 * Portfolio Card Component Generator
 */
function createPortfolioCard(project = {}) {
  const {
    title = 'Untitled Project',
    client = 'RAAJ Studios',
    category = 'Design',
    slug = '',
    images = {},
    tags = []
  } = project;

  const heroImage = images.hero || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop';

  const tagsHTML = tags.length > 0
    ? `<div class="tag-group">${tags.slice(0, 3).map(tag => `<span class="tag tag-light">${tag}</span>`).join('')}</div>`
    : '';

  return `
    <div class="card portfolio-card" data-slug="${slug}">
      <div class="portfolio-card-media">
        <img src="${heroImage}" alt="${title}" loading="lazy">
        <div class="portfolio-card-overlay">
          <span class="portfolio-card-badge">${category}</span>
          <div class="portfolio-card-body">
            <h3 class="portfolio-card-title">${title}</h3>
            <p class="portfolio-card-client">${client}</p>
            ${tagsHTML}
          </div>
        </div>
      </div>
    </div>
  `.trim();
}

function createPortfolioGrid(projectsList = []) {
  if (!Array.isArray(projectsList) || projectsList.length === 0) return '';
  const cardsHTML = projectsList.map(project => createPortfolioCard(project)).join('');
  return `<div class="grid grid-3-col portfolio-grid">${cardsHTML}</div>`;
}

function initPortfolioCardComponents() {
  const cardContainers = document.querySelectorAll('[data-component="portfolio-card"]');
  cardContainers.forEach(container => {
    const title = container.dataset.title || '';
    const client = container.dataset.client || '';
    const category = container.dataset.category || 'Design';
    const slug = container.dataset.slug || '';
    const image = container.dataset.image || '';
    const tags = container.dataset.tags ? container.dataset.tags.split(',').map(t => t.trim()) : [];

    if (title) {
      container.innerHTML = createPortfolioCard({
        title,
        client,
        category,
        slug,
        images: { hero: image },
        tags
      });

      const card = container.querySelector('.portfolio-card');
      if (card) {
        card.style.cursor = 'pointer';
        card.addEventListener('click', () => {
          if (window.ModalEngine) {
            ModalEngine.open({
              title: `${title} — Project Case Study`,
              size: 'lg',
              content: `
                <div style="display: grid; grid-template-columns: 1.2fr 1fr; gap: 24px; align-items: start;">
                  <img src="${image || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop'}" alt="${title}" style="width: 100%; border-radius: 12px; object-fit: cover;">
                  <div>
                    <span class="badge badge-primary" style="margin-bottom: 12px; display: inline-block;">${category}</span>
                    <h3 style="font-size: 1.6rem; margin-bottom: 8px;">${title}</h3>
                    <p style="color: var(--text-secondary); margin-bottom: 16px;"><strong>Client:</strong> ${client}</p>
                    <div style="margin-bottom: 20px; line-height: 1.6;">
                      <h4 style="font-size: 1rem; margin-bottom: 4px;">Project Overview</h4>
                      <p>Custom graphic design solution engineered by RAAJ Studios to elevate ${client}'s brand positioning and market presence.</p>
                    </div>
                    <div class="tag-group" style="margin-bottom: 24px;">
                      ${tags.map(t => `<span class="tag">${t}</span>`).join('')}
                    </div>
                    <a href="contact.html" class="btn btn-primary btn-block">Inquire Similar Project →</a>
                  </div>
                </div>
              `
            });
          }
        });
      }
    }
  });
}

/**
 * Testimonial Card Component Generator
 */
function createTestimonialCard({ quote = '', name = '', role = 'Client', company = '', avatarUrl = '', rating = 5 }) {
  const starsHTML = '★'.repeat(Math.min(5, Math.max(1, rating))) + '☆'.repeat(5 - Math.min(5, Math.max(1, rating)));
  const defaultAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(name || 'Client')}&background=EAF8FF&color=33B8FF`;
  const avatar = avatarUrl || defaultAvatar;

  const roleCompany = company ? `${role}, ${company}` : role;

  return `
    <div class="card testimonial-card">
      <div class="testimonial-stars">${starsHTML}</div>
      <p class="testimonial-quote">"${quote}"</p>
      <div class="testimonial-author">
        <img src="${avatar}" alt="${name}" class="testimonial-avatar" loading="lazy">
        <div class="testimonial-info">
          <h4>${name}</h4>
          <p>${roleCompany}</p>
        </div>
      </div>
    </div>
  `.trim();
}

function createTestimonialGrid(testimonialsList = []) {
  if (!Array.isArray(testimonialsList) || testimonialsList.length === 0) return '';
  const cardsHTML = testimonialsList.map(item => createTestimonialCard(item)).join('');
  return `<div class="grid grid-3-col testimonial-grid">${cardsHTML}</div>`;
}

function initTestimonialCardComponents() {
  const containers = document.querySelectorAll('[data-component="testimonial-card"]');
  containers.forEach(container => {
    const quote = container.dataset.quote || '';
    const name = container.dataset.name || '';
    const role = container.dataset.role || 'Client';
    const company = container.dataset.company || '';
    const avatarUrl = container.dataset.avatar || '';
    const rating = parseInt(container.dataset.rating || '5', 10);

    if (quote && name) {
      container.innerHTML = createTestimonialCard({ quote, name, role, company, avatarUrl, rating });
    }
  });
}

/**
 * Pricing Card Component Generator
 */
function createPricingCard({ title = '', price = '', period = '/ project', description = '', features = [], isPopular = false, ctaText = 'Contact Studio', ctaUrl = 'contact.html' }) {
  const popularTag = isPopular ? '<span class="pricing-popular-tag">Most Popular</span>' : '';
  const popularClass = isPopular ? 'popular' : '';

  const featuresHTML = features.length > 0
    ? `<ul class="pricing-features">${features.map(f => `<li class="pricing-feature">${f}</li>`).join('')}</ul>`
    : '';

  return `
    <div class="card pricing-card ${popularClass}">
      ${popularTag}
      <div class="pricing-header">
        <h3 class="pricing-title">${title}</h3>
        <p class="pricing-desc">${description}</p>
        <div class="pricing-price-container">
          <span class="pricing-price">${price}</span>
          <span class="pricing-period">${period}</span>
        </div>
      </div>
      ${featuresHTML}
      <div class="pricing-footer">
        <a href="${ctaUrl}" class="btn ${isPopular ? 'btn-primary' : 'btn-secondary'} btn-block">${ctaText}</a>
      </div>
    </div>
  `.trim();
}

function createPricingGrid(pricingList = []) {
  if (!Array.isArray(pricingList) || pricingList.length === 0) return '';
  const cardsHTML = pricingList.map(plan => createPricingCard(plan)).join('');
  return `<div class="grid grid-3-col pricing-grid">${cardsHTML}</div>`;
}

function initPricingCardComponents() {
  const containers = document.querySelectorAll('[data-component="pricing-card"]');
  containers.forEach(container => {
    const title = container.dataset.title || '';
    const price = container.dataset.price || '';
    const period = container.dataset.period || '/ project';
    const description = container.dataset.description || '';
    const features = container.dataset.features ? container.dataset.features.split(',').map(f => f.trim()) : [];
    const isPopular = container.dataset.popular === 'true';
    const ctaText = container.dataset.cta || 'Contact Studio';
    const ctaUrl = container.dataset.url || 'contact.html';

    if (title && price) {
      container.innerHTML = createPricingCard({ title, price, period, description, features, isPopular, ctaText, ctaUrl });
    }
  });
}

/**
 * Blog Card Component Generator
 */
function createBlogCard({ title = '', excerpt = '', date = '2026-08-01', category = 'Design Insights', imageUrl = '', slug = '', readTime = '5 min read' }) {
  const cover = imageUrl || 'https://images.unsplash.com/photo-1542744094-3a3172720a8a?w=800&auto=format&fit=crop';
  const postUrl = slug ? `blog.html?post=${slug}` : 'blog.html';

  return `
    <div class="card blog-card">
      <img src="${cover}" alt="${title}" class="blog-card-image" loading="lazy">
      <div class="blog-card-content">
        <div class="blog-card-meta">
          <span class="badge badge-primary">${category}</span>
          <span>${date}</span>
          <span>• ${readTime}</span>
        </div>
        <h3 class="blog-card-title">${title}</h3>
        <p class="blog-card-excerpt">${excerpt}</p>
        <a href="${postUrl}" class="service-card-link">Read Article →</a>
      </div>
    </div>
  `.trim();
}

function createBlogGrid(postsList = []) {
  if (!Array.isArray(postsList) || postsList.length === 0) return '';
  const cardsHTML = postsList.map(post => createBlogCard(post)).join('');
  return `<div class="grid grid-3-col blog-grid">${cardsHTML}</div>`;
}

function initBlogCardComponents() {
  const containers = document.querySelectorAll('[data-component="blog-card"]');
  containers.forEach(container => {
    const title = container.dataset.title || '';
    const excerpt = container.dataset.excerpt || '';
    const date = container.dataset.date || '';
    const category = container.dataset.category || 'Design Insights';
    const imageUrl = container.dataset.image || '';
    const slug = container.dataset.slug || '';
    const readTime = container.dataset.readtime || '5 min read';

    if (title) {
      container.innerHTML = createBlogCard({ title, excerpt, date, category, imageUrl, slug, readTime });
    }
  });
}

/**
 * Dynamic Component Fetch Loader
 */
async function loadComponent(id, file) {
  const container = document.getElementById(id);
  if (!container) return false;
  if (container.children.length > 0) return true; // Keep inline fallback if present

  try {
    const response = await fetch(file);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const html = await response.text();
    container.innerHTML = html;
    return true;
  } catch (err) {
    console.warn(`[Components] Could not fetch ${file} into #${id}, fallback used:`, err);
    return false;
  }
}

async function initializePageComponents() {
  try {
    await loadComponent("navbar", "components/navbar.html");
    await loadComponent("footer", "components/footer.html");
    const heroLoaded = await loadComponent("hero-component", "components/hero.html");

    if (heroLoaded && typeof initializeHero === 'function') {
      initializeHero();
    }
  } catch (e) {
    console.warn("[Components] Partial component fetch error, continuing inline render...", e);
  }

  initSectionHeaderComponents();
  initServiceCardComponents();
  initPortfolioCardComponents();
  initTestimonialCardComponents();
  initPricingCardComponents();
  initBlogCardComponents();

  if (typeof initializeNavigation === 'function') {
    initializeNavigation();
  }
}

document.addEventListener('DOMContentLoaded', initializePageComponents);

window.createSectionTitle = createSectionTitle;
window.initSectionHeaderComponents = initSectionHeaderComponents;
window.createServiceCard = createServiceCard;
window.createServiceGrid = createServiceGrid;
window.initServiceCardComponents = initServiceCardComponents;
window.createPortfolioCard = createPortfolioCard;
window.createPortfolioGrid = createPortfolioGrid;
window.initPortfolioCardComponents = initPortfolioCardComponents;
window.createTestimonialCard = createTestimonialCard;
window.createTestimonialGrid = createTestimonialGrid;
window.initTestimonialCardComponents = initTestimonialCardComponents;
window.createPricingCard = createPricingCard;
window.createPricingGrid = createPricingGrid;
window.initPricingCardComponents = initPricingCardComponents;
window.createBlogCard = createBlogCard;
window.createBlogGrid = createBlogGrid;
window.initBlogCardComponents = initBlogCardComponents;