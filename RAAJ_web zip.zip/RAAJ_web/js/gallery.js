/**
 * Image Gallery & Lightbox Controller (Task 17)
 * Interactive image lightbox overlay with keyboard navigation and position indicators.
 */
const GalleryLightbox = {
  activeImages: [],
  currentIndex: 0,
  overlayEl: null,

  /**
   * Open Lightbox Modal with array of image objects/urls
   * @param {Array<Object|string>} images - Array of image objects ({ src, title, caption }) or URL strings
   * @param {number} [startIndex=0] - Initial active image index
   */
  open(images = [], startIndex = 0) {
    if (!Array.isArray(images) || images.length === 0) return;

    this.activeImages = images.map(img => typeof img === 'string' ? { src: img } : img);
    this.currentIndex = Math.max(0, Math.min(startIndex, this.activeImages.length - 1));

    if (!this.overlayEl) {
      this.overlayEl = document.createElement('div');
      this.overlayEl.className = 'lightbox-overlay';
      this.overlayEl.innerHTML = `
        <button class="lightbox-close" aria-label="Close Lightbox">✕</button>
        <button class="lightbox-nav-btn lightbox-prev" aria-label="Previous Image">‹</button>
        <div class="lightbox-stage">
          <img src="" alt="" class="lightbox-img">
          <div class="lightbox-footer">
            <div class="lightbox-caption"></div>
            <div class="lightbox-counter"></div>
          </div>
        </div>
        <button class="lightbox-nav-btn lightbox-next" aria-label="Next Image">›</button>
      `;
      document.body.appendChild(this.overlayEl);

      // Event Listeners
      this.overlayEl.querySelector('.lightbox-close').addEventListener('click', () => this.close());
      this.overlayEl.querySelector('.lightbox-prev').addEventListener('click', () => this.prev());
      this.overlayEl.querySelector('.lightbox-next').addEventListener('click', () => this.next());

      this.overlayEl.addEventListener('click', (e) => {
        if (e.target === this.overlayEl || e.target.classList.contains('lightbox-stage')) {
          this.close();
        }
      });
    }

    this.renderCurrent();
    document.body.style.overflow = 'hidden';

    requestAnimationFrame(() => {
      this.overlayEl.classList.add('active');
    });
  },

  /**
   * Render Current Image
   */
  renderCurrent() {
    if (!this.overlayEl || this.activeImages.length === 0) return;

    const item = this.activeImages[this.currentIndex];
    const imgEl = this.overlayEl.querySelector('.lightbox-img');
    const captionEl = this.overlayEl.querySelector('.lightbox-caption');
    const counterEl = this.overlayEl.querySelector('.lightbox-counter');

    if (imgEl) {
      imgEl.src = item.src;
      imgEl.alt = item.title || item.caption || 'Gallery Image';
    }

    if (captionEl) {
      captionEl.textContent = item.title || item.caption || '';
    }

    if (counterEl) {
      counterEl.textContent = `${this.currentIndex + 1} / ${this.activeImages.length}`;
    }
  },

  /**
   * Next Image
   */
  next() {
    if (this.activeImages.length <= 1) return;
    this.currentIndex = (this.currentIndex + 1) % this.activeImages.length;
    this.renderCurrent();
  },

  /**
   * Previous Image
   */
  prev() {
    if (this.activeImages.length <= 1) return;
    this.currentIndex = (this.currentIndex - 1 + this.activeImages.length) % this.activeImages.length;
    this.renderCurrent();
  },

  /**
   * Close Lightbox
   */
  close() {
    if (!this.overlayEl) return;
    this.overlayEl.classList.remove('active');
    setTimeout(() => {
      document.body.style.overflow = '';
    }, 250);
  },

  /**
   * Auto-initialize Lightbox triggers in DOM
   */
  init() {
    // Keyboard Navigation
    document.addEventListener('keydown', (e) => {
      if (!this.overlayEl || !this.overlayEl.classList.contains('active')) return;

      if (e.key === 'Escape') this.close();
      if (e.key === 'ArrowRight') this.next();
      if (e.key === 'ArrowLeft') this.prev();
    });

    // Delegate click on [data-lightbox] elements
    document.addEventListener('click', (e) => {
      const trigger = e.target.closest('[data-lightbox]');
      if (!trigger) return;

      e.preventDefault();
      const group = trigger.dataset.lightboxGroup;

      if (group) {
        const groupElements = Array.from(document.querySelectorAll(`[data-lightbox-group="${group}"]`));
        const images = groupElements.map(el => ({
          src: el.getAttribute('href') || el.dataset.src || el.src,
          title: el.dataset.title || el.getAttribute('alt') || ''
        }));
        const index = groupElements.indexOf(trigger);
        this.open(images, index >= 0 ? index : 0);
      } else {
        const src = trigger.getAttribute('href') || trigger.dataset.src || trigger.src;
        const title = trigger.dataset.title || trigger.getAttribute('alt') || '';
        this.open([{ src, title }], 0);
      }
    });
  }
};

document.addEventListener('DOMContentLoaded', () => GalleryLightbox.init());

window.GalleryLightbox = GalleryLightbox;
